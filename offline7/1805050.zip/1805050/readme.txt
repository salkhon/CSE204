Stacksize needs to be increased on IDE for running quicksort on input s of size 10^5 and 10^6.

visual code command:
cd "INSERT DIRECTORY HERE" ; if ($?) { g++ -O2 -std=c++11 -Wall "-Wl,--stack=268435456" main.cpp -o main } ; if ($?) { .\main }